"""Inference-only loader for the original 32x32 three-component flow fields."""
import os
import numpy as np
import torch
from torch.utils.data import Dataset


class RealFluidFlowDataset(Dataset):
    """Select lowercase .txt files containing b16in, in original lexicographic order."""
    def __init__(self, input_dir):
        self.lqp = sorted(
            os.path.join(input_dir, name)
            for name in os.listdir(input_dir)
            if name.endswith('.txt') and 'b16in' in name
        )
        if not self.lqp:
            raise ValueError("No b16in*.txt flow files found in the input directory.")

    def __len__(self):
        return len(self.lqp)

    def __getitem__(self, index):
        path = self.lqp[index]
        try:
            with open(path, 'r') as stream:
                lines = stream.readlines()
                values = np.array([list(map(float, line.split())) for line in lines])
            # Match the original float64 parsing followed by float32 conversion.
            c1 = values[:, 0].reshape(32, 32)
            c2 = values[:, 1].reshape(32, 32)
            c3 = values[:, 2].reshape(32, 32)
            field = torch.tensor(np.stack([c1, c2, c3]), dtype=torch.float)
        except (OSError, ValueError, IndexError) as exc:
            raise ValueError(f"Cannot load a 32x32, three-component flow from {path!r}.") from exc
        # Normalization remains in the sampler, after the float32 conversion.
        return {'lq': field}
