"""Inference entry point used by run.sh; only fluid-flow text inputs are supported."""
import argparse
from pathlib import Path
from omegaconf import OmegaConf


def main():
    parser = argparse.ArgumentParser(description="15-step, x16 fluid-flow super-resolution.")
    parser.add_argument("-i", "--input-dir", required=True, help="Directory of 32x32 b16in*.txt flow fields.")
    parser.add_argument("-o", "--output-dir", default="results", help="Directory for results_N.txt files.")
    parser.add_argument("--checkpoint", required=True, help="EMA checkpoint from the matching 15-step training run.")
    parser.add_argument("--config", default="configs/fluidflow.yaml", help="Model and 15-step diffusion configuration.")
    parser.add_argument("--seed", type=int, default=12345, help="Original inference seed.")
    args = parser.parse_args()
    if not Path(args.checkpoint).is_file():
        parser.error("--checkpoint must name an existing checkpoint file.")
    configs = OmegaConf.load(args.config)
    configs.model.ckpt_path = args.checkpoint
    if configs.diffusion.params.steps != 15:
        parser.error("This release uses 15 steps; the checkpoint must match the training schedule.")
    # Heavy model imports are delayed so --help works before GPU setup.
    from sampler import ResShiftSampler
    sampler = ResShiftSampler(configs, seed=args.seed, use_amp=True)
    sampler.inference(args.input_dir, args.output_dir)


if __name__ == "__main__":
    main()
