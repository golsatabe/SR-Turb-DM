"""Construct the fluid-flow diffusion process from the YAML configuration."""
from . import gaussian_diffusion as gd
from .respace import SpacedDiffusion, space_timesteps

def create_gaussian_diffusion(
    *,
    normalize_input,
    schedule_name,
    sf=16,
    min_noise_level=0.01,
    steps=15,
    kappa=1,
    etas_end=0.99,
    schedule_kwargs=None,
    weighted_mse=False,
    predict_type='xstart',
    timestep_respacing=None,
    scale_factor=None,
    latent_flag=False,
):
    """Create the configured flow diffusion process. Both release configurations select all 15 steps."""
    if predict_type != 'xstart' or weighted_mse or normalize_input or latent_flag or (scale_factor != 1.0):
        raise ValueError(
            'Use xstart, unweighted MSE, direct flow space, and scale_factor=1.0, as in the supplied configuration.',
        )
    sqrt_etas = gd.get_named_eta_schedule(
        schedule_name,
        num_diffusion_timesteps=steps,
        min_noise_level=min_noise_level,
        etas_end=etas_end,
        kappa=kappa,
        kwargs=schedule_kwargs,
    )
    if timestep_respacing is None:
        timestep_respacing = steps
    else:
        assert isinstance(timestep_respacing, int)
    model_mean_type = gd.ModelMeanType.START_X
    return SpacedDiffusion(
        use_timesteps=space_timesteps(steps, timestep_respacing),
        sqrt_etas=sqrt_etas,
        kappa=kappa,
        model_mean_type=model_mean_type,
        loss_type=gd.LossType.MSE,
        scale_factor=scale_factor,
        normalize_input=normalize_input,
        sf=sf,
        latent_flag=latent_flag,
    )
