#!/usr/bin/env bash
#SBATCH --job-name=flow_test_15
#SBATCH --gres=gpu:1
#SBATCH --mem=100G
#SBATCH --cpus-per-task=10
#SBATCH --output=test_%j.out
#SBATCH --error=test_%j.err
set -euo pipefail

# Activate your existing PyTorch/CUDA environment before running or submitting.
# Slurm: cd to this folder, then sbatch run.sh; add a partition/account if needed.
cd "${SLURM_SUBMIT_DIR:-$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)}"
if [[ -z "${SLURM_JOB_ID:-}" ]]; then
    export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
fi

# Edit these paths or pass environment variables. GT is not used for prediction.
INPUT_DIR="${INPUT_DIR:-data/test/lq}"
OUTPUT_DIR="${OUTPUT_DIR:-results}"
CHECKPOINT="${CHECKPOINT:-weights/ema_model_200000.pth}"
CONFIG_PATH="${CONFIG_PATH:-configs/fluidflow.yaml}"
SEED="${SEED:-12345}"
[[ -d "$INPUT_DIR" ]] || { echo "Missing input directory: $INPUT_DIR" >&2; exit 1; }
[[ -f "$CHECKPOINT" ]] || { echo "Missing checkpoint: $CHECKPOINT" >&2; exit 1; }

# Use EMA weights from the matching 15-step training run, not an old 10-step run.
# One visible GPU and one sample at a time preserve the original launch setting.
python inference_resshift.py \
    --input-dir "$INPUT_DIR" \
    --output-dir "$OUTPUT_DIR" \
    --checkpoint "$CHECKPOINT" \
    --config "$CONFIG_PATH" \
    --seed "$SEED"
