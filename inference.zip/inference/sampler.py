"""Original fluid-flow inference arithmetic with unused application/plotting branches removed."""
import random
from contextlib import nullcontext
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from datapipe.datasets import RealFluidFlowDataset
from utils import util_common, util_net


class ResShiftSampler:
    def __init__(self, configs, seed=12345, use_amp=True):
        if torch.cuda.device_count() != 1:
            raise RuntimeError("Expose exactly one CUDA GPU for this inference workflow.")
        self.configs = configs
        self.seed = seed
        self.use_amp = use_amp
        self.setup_seed()
        self.build_model()

    def setup_seed(self):
        random.seed(self.seed)
        np.random.seed(self.seed)
        torch.manual_seed(self.seed)
        torch.cuda.manual_seed_all(self.seed)

    def build_model(self):
        print(f"Building fluid-flow diffusion with {self.configs.diffusion.params.steps} steps.")
        # Keep model initialization before checkpoint loading: initialization consumes RNG.
        self.base_diffusion = util_common.instantiate_from_config(self.configs.diffusion)
        model = util_common.get_obj_from_str(self.configs.model.target)(**self.configs.model.params)
        model.cuda()
        state = torch.load(self.configs.model.ckpt_path, map_location="cuda:0")
        if 'state_dict' in state:
            state = state['state_dict']
        util_net.reload_model(model, state)
        for parameter in model.parameters():
            parameter.requires_grad = False
        self.model = model.eval()

    def sample_func(self, y0):
        """Predict all three normalized flow components without clipping their amplitudes."""
        lq_interpolated = F.interpolate(y0, scale_factor=16, mode='bicubic')
        return self.base_diffusion.p_sample_loop(
            y=y0,
            model=self.model,
            first_stage_model=None,
            noise=None,
            noise_repeat=False,
            clip_denoised=False,
            denoised_fn=None,
            model_kwargs={'lq': lq_interpolated},
            progress=False,
        )

    def process_diffused(self, y0):
        """Retain the original second sampling pass to preserve RNG for the NEXT sample.

        The old plotting buffers, unused timestep counter, and debug prints are
        removed. Deleting this loop itself changes later seeded predictions.
        It deliberately remains outside the AMP context, as in the original.
        """
        lq_interpolated = F.interpolate(y0, scale_factor=16, mode='bicubic')
        for _ in self.base_diffusion.p_sample_loop_progressive(
            y=y0,
            model=self.model,
            first_stage_model=None,
            noise=None,
            clip_denoised=False,
            model_kwargs={'lq': lq_interpolated},
            device="cuda",
            progress=False,
        ):
            pass

    def inference(self, input_dir, output_dir):
        """Save one 512x512, three-column results_N.txt file per input (batch size one)."""
        input_dir, output_dir = Path(input_dir), Path(output_dir)
        if not input_dir.is_dir():
            raise NotADirectoryError(input_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        dataset = RealFluidFlowDataset(input_dir)
        # A larger batch changed normalization and overwrote output files in the
        # original code. This release explicitly retains the run.sh batch of one.
        loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False, drop_last=False)
        print(f"Found {len(dataset)} flow fields in {input_dir}.")
        for index, data in enumerate(loader):
            lq = data['lq']
            # Preserve per-component maxima and in-place float32 division order.
            s1 = torch.max(torch.abs(lq[:, 0, :, :]))
            s2 = torch.max(torch.abs(lq[:, 1, :, :]))
            s3 = torch.max(torch.abs(lq[:, 2, :, :]))
            lq[:, 0, :, :] /= s1
            lq[:, 1, :, :] /= s2
            lq[:, 2, :, :] /= s3
            context = torch.cuda.amp.autocast if self.use_amp else nullcontext
            with context():
                results = self.sample_func(lq.cuda())
            self.process_diffused(lq.cuda())
            results[:, 0, :, :] *= s1
            results[:, 1, :, :] *= s2
            results[:, 2, :, :] *= s3
            field = results[0].cpu().numpy()
            output = np.hstack((field[0].reshape(-1, 1), field[1].reshape(-1, 1), field[2].reshape(-1, 1)))
            np.savetxt(output_dir / f"results_{index}.txt", output, fmt='%.6f', delimiter=' ')
            print(f"Saved results_{index}.txt ({index + 1}/{len(dataset)}).")
