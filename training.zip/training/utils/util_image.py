"""Original fluid-field PSNR metric over all three components."""
import math
import numpy as np

def calculate_psnr(im1, im2):
    """Use the original fluid-field PSNR, with peak magnitude measured from the reference field (no RGB conversion)."""
    if im1.shape != im2.shape:
        raise ValueError('Input arrays must have the same dimensions.')
    mse = np.mean((im1 - im2) ** 2)
    if mse == 0:
        return float('inf')
    max_value = np.max(np.abs(im2))
    return 20 * math.log10(max_value / math.sqrt(mse))

def batch_PSNR(img, imclean, border=0):
    if img.shape != imclean.shape:
        raise ValueError('Input arrays must have the same dimensions.')
    Img = img.data.cpu().numpy()
    Iclean = imclean.data.cpu().numpy()
    PSNR = 0.0
    for i in range(img.shape[0]):
        PSNR += calculate_psnr(Img[i], Iclean[i])
    return PSNR
