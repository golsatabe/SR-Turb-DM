"""Checkpoint and parameter helpers used by this workflow."""

def calculate_parameters(net):
    out = 0
    for param in net.parameters():
        out += param.numel()
    return out

def reload_model(model, ckpt):
    """Load the original checkpoint tensors, retaining support for distributed-training key prefixes."""
    module_flag = list(ckpt.keys())[0].startswith('module.')
    compile_flag = '_orig_mod' in list(ckpt.keys())[0]
    for source_key, source_value in model.state_dict().items():
        target_key = source_key
        if compile_flag and (not '_orig_mod.' in source_key):
            target_key = '_orig_mod.' + target_key
        if module_flag and (not source_key.startswith('module')):
            target_key = 'module.' + target_key
        assert target_key in ckpt
        source_value.copy_(ckpt[target_key])
