"""Training entry point used by run.sh."""
import argparse
from pathlib import Path
from omegaconf import OmegaConf
from utils.util_common import get_obj_from_str


def main():
    parser = argparse.ArgumentParser(description="Train three-component fluid-flow super-resolution.")
    parser.add_argument("--cfg_path", default="configs/fluidflow.yaml", help="Flow model, diffusion, and data configuration.")
    parser.add_argument("--save_dir", default="logging", help="Parent directory for a NEW experiment.")
    parser.add_argument("--resume", default="", help="Optional 15-step training checkpoint; EMA companion must also exist.")
    args = parser.parse_args()
    configs = OmegaConf.load(args.cfg_path)
    configs.cfg_path, configs.save_dir, configs.resume = args.cfg_path, args.save_dir, args.resume
    # A resume writes into the existing run, exactly as in the original trainer.
    if args.resume and not Path(args.resume).is_file():
        parser.error("--resume must name an existing training checkpoint.")
    if configs.diffusion.params.steps != 15:
        parser.error("This release is configured for 15 diffusion steps; update train and test together.")
    trainer = get_obj_from_str(configs.trainer.target)(configs)
    trainer.train()


if __name__ == "__main__":
    main()
