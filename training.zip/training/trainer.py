"""Train the fluid-flow super-resolution model. Core loss, optimization, validation, and checkpoint behavior are retained."""
import os, sys, math, random, datetime, functools
import lpips
import numpy as np
import matplotlib
matplotlib.use("Agg")  # Save training plots without a desktop display.
import matplotlib.pyplot as plt
from pathlib import Path
from loguru import logger
from copy import deepcopy
from omegaconf import OmegaConf
from collections import OrderedDict
from einops import rearrange
from contextlib import nullcontext
from datapipe.datasets import create_dataset
from utils import util_net
from utils import util_common
from utils import util_image
import torch
import torch.cuda.amp as amp
import torch.nn.functional as F
import torch.utils.data as udata
import torch.distributed as dist
import torch.multiprocessing as mp
from torch.nn.parallel import DistributedDataParallel as DDP
import pywt
from models.basic_ops import mean_flat

class TrainerBase:
    """Common training lifecycle: setup, checkpoint loading, dataloaders, optimization, logging, and EMA."""

    def __init__(self, configs):
        self.configs = configs
        self.setup_dist()
        self.setup_seed()

    def setup_dist(self):
        num_gpus = torch.cuda.device_count()
        if num_gpus > 1:
            if mp.get_start_method(allow_none=True) is None:
                mp.set_start_method('spawn')
            rank = int(os.environ['LOCAL_RANK'])
            torch.cuda.set_device(rank % num_gpus)
            dist.init_process_group(
                timeout=datetime.timedelta(seconds=3600),
                backend='nccl',
                init_method='env://',
            )
        self.num_gpus = num_gpus
        self.rank = int(os.environ['LOCAL_RANK']) if num_gpus > 1 else 0

    def setup_seed(self, seed=None, global_seeding=None):
        if seed is None:
            seed = self.configs.train.get('seed', 12345)
        if global_seeding is None:
            global_seeding = self.configs.train.global_seeding
            assert isinstance(global_seeding, bool)
        if not global_seeding:
            seed += self.rank
            torch.cuda.manual_seed(seed)
        else:
            torch.cuda.manual_seed_all(seed)
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)

    def init_logger(self):
        if self.configs.resume:
            assert self.configs.resume.endswith('.pth')
            save_dir = Path(self.configs.resume).parents[1]
            project_id = save_dir.name
        else:
            project_id = datetime.datetime.now().strftime('%Y-%m-%d-%H-%M')
            save_dir = Path(self.configs.save_dir) / project_id
            if not save_dir.exists() and self.rank == 0:
                save_dir.mkdir(parents=True)
        if self.rank == 0:
            self.log_step = {phase: 1 for phase in ['train', 'val']}
            self.log_step_img = {phase: 1 for phase in ['train', 'val']}
        logtxet_path = save_dir / 'training.log'
        if self.rank == 0:
            if logtxet_path.exists():
                assert self.configs.resume
            self.logger = logger
            self.logger.remove()
            self.logger.add(logtxet_path, format='{message}', mode='a', level='INFO')
            self.logger.add(sys.stdout, format='{message}')
        ckpt_dir = save_dir / 'ckpts'
        self.ckpt_dir = ckpt_dir
        if self.rank == 0 and (not ckpt_dir.exists()):
            ckpt_dir.mkdir()
        if 'ema_rate' in self.configs.train:
            self.ema_rate = self.configs.train.ema_rate
            assert isinstance(self.ema_rate, float), 'Ema rate must be a float number'
            ema_ckpt_dir = save_dir / 'ema_ckpts'
            self.ema_ckpt_dir = ema_ckpt_dir
            if self.rank == 0 and (not ema_ckpt_dir.exists()):
                ema_ckpt_dir.mkdir()
        self.local_logging = self.configs.train.local_logging
        if self.rank == 0 and self.local_logging:
            image_dir = save_dir / 'images'
            if not image_dir.exists():
                (image_dir / 'train').mkdir(parents=True)
                (image_dir / 'val').mkdir(parents=True)
            self.image_dir = image_dir
        if self.rank == 0:
            self.logger.info(OmegaConf.to_yaml(self.configs))

    def resume_from_ckpt(self):
        """Resume the original iteration/scaler/EMA logic. This implementation does not restore optimizer or RNG state."""

        def _load_ema_state(ema_state, ckpt):
            for key in ema_state.keys():
                if key not in ckpt and key.startswith('module'):
                    ema_state[key] = deepcopy(ckpt[7:].detach().data)
                elif key not in ckpt and (not key.startswith('module')):
                    ema_state[key] = deepcopy(ckpt['module.' + key].detach().data)
                else:
                    ema_state[key] = deepcopy(ckpt[key].detach().data)
        if self.configs.resume:
            assert self.configs.resume.endswith('.pth') and os.path.isfile(self.configs.resume)
            if self.rank == 0:
                self.logger.info(f'=> Loaded checkpoint from {self.configs.resume}')
            ckpt = torch.load(self.configs.resume, map_location=f'cuda:{self.rank}')
            util_net.reload_model(self.model, ckpt['state_dict'])
            torch.cuda.empty_cache()
            self.iters_start = ckpt['iters_start']
            for ii in range(1, self.iters_start + 1):
                self.adjust_lr(ii)
            if self.rank == 0:
                self.log_step = ckpt['log_step']
                self.log_step_img = ckpt['log_step_img']
            if self.rank == 0 and hasattr(self, 'ema_rate'):
                ema_ckpt_path = self.ema_ckpt_dir / ('ema_' + Path(self.configs.resume).name)
                self.logger.info(f'=> Loaded EMA checkpoint from {str(ema_ckpt_path)}')
                ema_ckpt = torch.load(ema_ckpt_path, map_location=f'cuda:{self.rank}')
                _load_ema_state(self.ema_state, ema_ckpt)
            torch.cuda.empty_cache()
            if self.amp_scaler is not None:
                if 'amp_scaler' in ckpt:
                    self.amp_scaler.load_state_dict(ckpt['amp_scaler'])
                    if self.rank == 0:
                        self.logger.info('Loading scaler from resumed state...')
            self.setup_seed(seed=self.iters_start)
        else:
            self.iters_start = 0

    def setup_optimizaton(self):
        self.optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=self.configs.train.lr,
            weight_decay=self.configs.train.weight_decay,
        )
        self.amp_scaler = amp.GradScaler() if self.configs.train.use_amp else None

    def build_model(self):
        params = self.configs.model.get('params', dict)
        model = util_common.get_obj_from_str(self.configs.model.target)(**params)
        model.cuda()
        if self.configs.model.ckpt_path is not None:
            ckpt_path = self.configs.model.ckpt_path
            if self.rank == 0:
                self.logger.info(f'Initializing model from {ckpt_path}')
            ckpt = torch.load(ckpt_path, map_location=f'cuda:{self.rank}')
            if 'state_dict' in ckpt:
                ckpt = ckpt['state_dict']
            util_net.reload_model(model, ckpt)
        if self.num_gpus > 1:
            self.model = DDP(model, device_ids=[self.rank], static_graph=False)
        else:
            self.model = model
        if self.rank == 0 and hasattr(self.configs.train, 'ema_rate'):
            self.ema_model = deepcopy(model).cuda()
            self.ema_state = OrderedDict(
                {key: deepcopy(value.data) for key, value in self.model.state_dict().items()},
            )
            self.ema_ignore_keys = [x for x in self.ema_state.keys() if 'running_' in x or 'num_batches_tracked' in x]
        self.print_model_info()

    def build_dataloader(self):
        """Keep the original global batch, distributed sampler, worker seeds, and validation ordering."""

        def _wrap_loader(loader):
            while True:
                yield from loader
        datasets = {'train': create_dataset(self.configs.data.get('train', dict))}
        if hasattr(self.configs.data, 'val') and self.rank == 0:
            datasets['val'] = create_dataset(self.configs.data.get('val', dict))
        if self.rank == 0:
            for phase in datasets.keys():
                length = len(datasets[phase])
                self.logger.info(
                    'Number of flow samples in {:s} data set: {:d}'.format(phase, length),
                )
        if self.num_gpus > 1:
            sampler = udata.distributed.DistributedSampler(
                datasets['train'],
                num_replicas=self.num_gpus,
                rank=self.rank,
            )
        else:
            sampler = None
        dataloaders = {
            'train': _wrap_loader(
                udata.DataLoader(
                    datasets['train'],
                    batch_size=self.configs.train.batch[0] // self.num_gpus,
                    shuffle=False if self.num_gpus > 1 else True,
                    drop_last=True,
                    num_workers=min(self.configs.train.num_workers, 4),
                    pin_memory=True,
                    prefetch_factor=self.configs.train.get('prefetch_factor', 2),
                    worker_init_fn=my_worker_init_fn,
                    sampler=sampler,
                ),
            ),
        }
        if hasattr(self.configs.data, 'val') and self.rank == 0:
            dataloaders['val'] = udata.DataLoader(
                datasets['val'],
                batch_size=self.configs.train.batch[1],
                shuffle=False,
                drop_last=False,
                num_workers=0,
                pin_memory=True,
            )
        self.datasets = datasets
        self.dataloaders = dataloaders
        self.sampler = sampler

    def print_model_info(self):
        if self.rank == 0:
            num_params = util_net.calculate_parameters(self.model) / 1000 ** 2
            self.logger.info(f'Number of parameters: {num_params:.2f}M')

    def train(self):
        self.init_logger()
        self.build_model()
        self.setup_optimizaton()
        self.resume_from_ckpt()
        self.build_dataloader()
        self.model.train()
        num_iters_epoch = math.ceil(len(self.datasets['train']) / self.configs.train.batch[0])
        for ii in range(self.iters_start, self.configs.train.iterations):
            self.current_iters = ii + 1
            data = self.prepare_data(next(self.dataloaders['train']))
            self.training_step(data)
            if 'val' in self.dataloaders and (ii + 1) % self.configs.train.get('val_freq', 10) == 0:
                self.validation()
            self.adjust_lr()
            if (ii + 1) % self.configs.train.save_freq == 0:
                self.save_ckpt()
            if (ii + 1) % num_iters_epoch == 0 and self.sampler is not None:
                self.sampler.set_epoch(ii + 1)

    def save_ckpt(self):
        if self.rank == 0:
            ckpt_path = self.ckpt_dir / 'model_{:d}.pth'.format(self.current_iters)
            ckpt = {
                'iters_start': self.current_iters,
                'log_step': {phase: self.log_step[phase] for phase in ['train', 'val']},
                'log_step_img': {phase: self.log_step_img[phase] for phase in ['train', 'val']},
                'state_dict': self.model.state_dict(),
            }
            if self.amp_scaler is not None:
                ckpt['amp_scaler'] = self.amp_scaler.state_dict()
            torch.save(ckpt, ckpt_path)
            if hasattr(self, 'ema_rate'):
                ema_ckpt_path = self.ema_ckpt_dir / 'ema_model_{:d}.pth'.format(self.current_iters)
                torch.save(self.ema_state, ema_ckpt_path)

    def reload_ema_model(self):
        if self.rank == 0:
            if self.num_gpus > 1:
                model_state = {key[7:]: value for key, value in self.ema_state.items()}
            else:
                model_state = self.ema_state
            self.ema_model.load_state_dict(model_state)

    @torch.no_grad()
    def update_ema_model(self):
        if self.num_gpus > 1:
            dist.barrier()
        if self.rank == 0:
            source_state = self.model.state_dict()
            rate = self.ema_rate
            for key, value in self.ema_state.items():
                if key in self.ema_ignore_keys:
                    self.ema_state[key] = source_state[key]
                else:
                    self.ema_state[key].mul_(rate).add_(
                        source_state[key].detach().data,
                        alpha=1 - rate,
                    )

    def logging_image(self, im_tensor, tag, phase, add_global_step=False, nrow=8):
        batch_size = im_tensor.shape[0]
        H, W = (im_tensor.shape[2], im_tensor.shape[3])
        ncol = (batch_size + nrow - 1) // nrow
        plot_spacing = 0.5
        fig_size_per_plot = 2.0
        fig_width = nrow * fig_size_per_plot + (nrow - 1) * plot_spacing
        fig_height = ncol * fig_size_per_plot + (ncol - 1) * plot_spacing
        for component in range(3):
            fig, axes = plt.subplots(ncol, nrow, figsize=(fig_width, fig_height))
            fig.subplots_adjust(hspace=plot_spacing, wspace=plot_spacing)
            axes = np.atleast_2d(axes)
            for idx in range(batch_size):
                row = idx // nrow
                col = idx % nrow
                ax = axes[row, col]
                x = np.linspace(0, 2 * np.pi, H)
                y = np.linspace(0, 2 * np.pi, W)
                X, Y = np.meshgrid(x, y)
                data_reshaped = im_tensor[idx, component, :, :]
                data_reshaped_cpu = data_reshaped.cpu().numpy()
                ax.pcolormesh(X, Y, data_reshaped_cpu, shading='auto', cmap='jet')
                ax.axis('square')
                ax.axis('off')
            im_path = str(
                os.path.join(
                    self.image_dir,
                    phase,
                    f'{tag}{component}-{self.log_step_img[phase]}.png',
                ),
            )
            os.makedirs(os.path.dirname(im_path), exist_ok=True)
            plt.savefig(im_path, dpi=300, bbox_inches='tight')
            plt.close(fig)
        if add_global_step:
            self.log_step_img[phase] += 1

class TrainerDifIR(TrainerBase):
    """Fluid-flow training with the original MSE/LPIPS objective and wavelet-dependent NaN fallback."""

    def setup_optimizaton(self):
        super().setup_optimizaton()
        if self.configs.train.lr_schedule == 'cosin':
            self.lr_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
                optimizer=self.optimizer,
                T_max=self.configs.train.iterations - self.configs.train.warmup_iterations,
                eta_min=self.configs.train.lr_min,
            )

    def build_model(self):
        super().build_model()
        if self.rank == 0 and hasattr(self.configs.train, 'ema_rate'):
            self.ema_ignore_keys.extend(
                [x for x in self.ema_state.keys() if 'relative_position_index' in x],
            )
        self.autoencoder = None
        lpips_net = 'vgg'
        if self.rank == 0:
            self.logger.info(f'Loading LPIPS Metric: {lpips_net}...')
        lpips_loss = lpips.LPIPS(net=lpips_net).to(f'cuda:{self.rank}')
        for params in lpips_loss.parameters():
            params.requires_grad_(False)
        lpips_loss.eval()
        self.lpips_loss = lpips_loss
        params = self.configs.diffusion.get('params', dict)
        self.base_diffusion = util_common.get_obj_from_str(self.configs.diffusion.target)(**params)

    @torch.no_grad()
    def prepare_data(self, data, dtype=torch.float32, phase='train'):
        """Transfer fields to CUDA; preserve the original training-only NaN filtering."""
        if phase == 'train':
            im_gt = data['gt'].cuda()
            im_lq = data['lq'].cuda()
            self.lq, self.gt, flag_nan = replace_nan_in_batch(im_lq, im_gt)
            if flag_nan:
                with open(f'records_nan_rank{self.rank}.log', 'a') as f:
                    f.write(f'Find Nan value in rank{self.rank}\n')
            return {'lq': self.lq, 'gt': self.gt}
        return {key: value.cuda().to(dtype=dtype) for key, value in data.items()}

    def compute_weight_map(self, tensor, wavelet='haar'):
        """Build the original signed Haar-detail weight map used by the loss diagnostics and fallback check."""
        batch_size, channels, height, width = tensor.shape
        weight_maps = []
        for b in range(batch_size):
            channel_weights = []
            for c in range(channels):
                coeffs = pywt.dwt2(tensor[b, c].cpu().numpy(), wavelet)
                _, (LH, HL, HH) = coeffs
                high_freq = (LH + HL + HH) / 3.0
                high_freq = torch.tensor(high_freq, device=tensor.device, dtype=tensor.dtype)
                high_freq_resized = F.interpolate(
                    high_freq.unsqueeze(0).unsqueeze(0),
                    size=(height, width),
                    mode='bicubic',
                    align_corners=False,
                ).squeeze(
                    0,
                ).squeeze(
                    0,
                )
                channel_weights.append(high_freq_resized)
            weight_maps.append(torch.stack(channel_weights, dim=0))
        weight_map = torch.stack(weight_maps, dim=0)
        weight_map = (weight_map - weight_map.min()) / (weight_map.max() - weight_map.min() + 1e-08)
        return weight_map

    def backward_step(self, dif_loss_wrapper, micro_data, num_grad_accumulate, tt):
        """Weighted LPIPS controls the NaN fallback; the ordinary objective uses UNWEIGHTED LPIPS. Do not remove the weighted computation."""
        loss_coef = self.configs.train.get('loss_coef')
        context = torch.cuda.amp.autocast if self.configs.train.use_amp else nullcontext
        with context():
            losses, z_t, z0_pred = dif_loss_wrapper()
            x0_pred = self.base_diffusion.decode_first_stage(z0_pred, self.autoencoder)
            weight_map = self.compute_weight_map(micro_data['gt'])
            weighted_x0_pred = weight_map * x0_pred
            weighted_gt = weight_map * micro_data['gt']
            losses['lpips'] = self.lpips_loss(weighted_x0_pred, weighted_gt).to(z0_pred.dtype).view(-1)
            losses['lpip'] = self.lpips_loss(x0_pred, micro_data['gt']).to(z0_pred.dtype).view(-1)
            losses['l2'] = mean_flat((weighted_x0_pred - weighted_gt) ** 2)
            flag_nan = torch.any(torch.isnan(losses['lpips']))
            if flag_nan:
                losses['lpips'] = torch.nan_to_num(losses['lpips'], nan=0.0)
            assert losses['l2'].shape == losses['lpips'].shape
            if flag_nan:
                losses['loss'] = losses['mse']
            else:
                losses['loss'] = losses['mse'] * loss_coef[0] + losses['lpip'] * loss_coef[1]
            loss = losses['loss'].mean() / num_grad_accumulate
        if self.amp_scaler is None:
            loss.backward()
        else:
            self.amp_scaler.scale(loss).backward()
        return (losses, z0_pred, z_t)

    def training_step(self, data):
        """Accumulate microbatch gradients before one optimizer/EMA update; retain the original random-draw order."""
        current_batchsize = data['gt'].shape[0]
        micro_batchsize = self.configs.train.microbatch
        num_grad_accumulate = math.ceil(current_batchsize / micro_batchsize)
        for jj in range(0, current_batchsize, micro_batchsize):
            micro_data = {key: value[jj:jj + micro_batchsize,] for key, value in data.items()}
            last_batch = jj + micro_batchsize >= current_batchsize
            tt = torch.randint(
                0,
                self.base_diffusion.num_timesteps,
                size=(micro_data['gt'].shape[0],),
                device=f'cuda:{self.rank}',
            )
            latent_downsamping_sf = 1
            latent_resolution = micro_data['gt'].shape[-1] // latent_downsamping_sf
            noise_chn = micro_data['gt'].shape[1]
            noise = torch.randn(
                size=(micro_data['gt'].shape[0], noise_chn) + (latent_resolution,) * 2,
                device=micro_data['gt'].device,
            )
            if self.configs.model.params.cond_lq:
                lq_interpolated = F.interpolate(micro_data['lq'], scale_factor=16, mode='bicubic')
                model_kwargs = {'lq': lq_interpolated}
            else:
                model_kwargs = None
            compute_losses = functools.partial(
                self.base_diffusion.training_losses,
                self.model,
                micro_data['gt'],
                micro_data['lq'],
                tt,
                first_stage_model=None,
                model_kwargs=model_kwargs,
                noise=noise,
            )
            if last_batch or self.num_gpus <= 1:
                losses, z0_pred, z_t = self.backward_step(compute_losses, micro_data, num_grad_accumulate, tt)
            else:
                with self.model.no_sync():
                    losses, z0_pred, z_t = self.backward_step(compute_losses, micro_data, num_grad_accumulate, tt)
            if last_batch:
                self.log_step_train(losses, tt, micro_data, z_t, z0_pred.detach())
        if self.configs.train.use_amp:
            self.amp_scaler.step(self.optimizer)
            self.amp_scaler.update()
        else:
            self.optimizer.step()
        self.model.zero_grad()
        if hasattr(self.configs.train, 'ema_rate'):
            self.update_ema_model()

    def adjust_lr(self, current_iters=None):
        base_lr = self.configs.train.lr
        warmup_steps = self.configs.train.warmup_iterations
        current_iters = self.current_iters if current_iters is None else current_iters
        if current_iters <= warmup_steps:
            for params_group in self.optimizer.param_groups:
                params_group['lr'] = current_iters / warmup_steps * base_lr
        elif hasattr(self, 'lr_scheduler'):
            self.lr_scheduler.step()

    def log_step_train(self, loss, tt, batch, z_t, z0_pred, phase='train'):
        if self.rank == 0:
            num_timesteps = self.base_diffusion.num_timesteps
            record_steps = [1, num_timesteps // 2 + 1, num_timesteps]
            if self.current_iters % self.configs.train.log_freq[0] == 1:
                self.loss_mean = {key: torch.zeros(size=(len(record_steps),), dtype=torch.float64) for key in loss.keys()}
                self.loss_count = torch.zeros(size=(len(record_steps),), dtype=torch.float64)
            for jj in range(len(record_steps)):
                for key, value in loss.items():
                    index = record_steps[jj] - 1
                    mask = torch.where(tt == index, torch.ones_like(tt), torch.zeros_like(tt))
                    current_loss = torch.sum(value.detach() * mask)
                    self.loss_mean[key][jj] += current_loss.item()
                self.loss_count[jj] += mask.sum().item()
            if self.current_iters % self.configs.train.log_freq[0] == 0:
                if torch.any(self.loss_count == 0):
                    self.loss_count += 0.0001
                for key in loss.keys():
                    self.loss_mean[key] /= self.loss_count
                log_str = 'Train, {:06d},{:06d}, Loss/MSE, '.format(
                    self.current_iters,
                    self.configs.train.iterations,
                )
                for jj, current_record in enumerate(record_steps):
                    log_str += 't({:d}),{:.1e},{:.1e},{:.1e},{:.1e},{:.1e}, '.format(
                        current_record,
                        self.loss_mean['loss'][jj].item(),
                        self.loss_mean['l2'][jj].item(),
                        self.loss_mean['lpips'][jj].item(),
                        self.loss_mean['mse'][jj].item(),
                        self.loss_mean['lpip'][jj].item(),
                    )
                log_str += 'lr:{:.2e}'.format(self.optimizer.param_groups[0]['lr'])
                self.logger.info(log_str)
            if self.current_iters % self.configs.train.log_freq[1] == 0:
                self.logging_image(batch['lq'], tag='lq', phase=phase, add_global_step=False)
                self.logging_image(batch['gt'], tag='gt', phase=phase, add_global_step=False)
                x_t = self.base_diffusion.decode_first_stage(
                    self.base_diffusion._scale_input(z_t, tt),
                    self.autoencoder,
                )
                self.logging_image(x_t, tag='diffused', phase=phase, add_global_step=False)
                x0_pred = self.base_diffusion.decode_first_stage(z0_pred, self.autoencoder)
                self.logging_image(x0_pred, tag='x0-pred', phase=phase, add_global_step=True)

    def validation(self, phase='val'):
        """Sample validation fields and retain the original PSNR, MSE, LPIPS, and progress plots."""
        if self.rank == 0:
            if self.configs.train.use_ema_val:
                self.reload_ema_model()
                self.ema_model.eval()
            else:
                self.model.eval()
            indices = np.linspace(
                0,
                self.base_diffusion.num_timesteps,
                self.base_diffusion.num_timesteps if self.base_diffusion.num_timesteps < 5 else 4,
                endpoint=False,
                dtype=np.int64,
            ).tolist(
            )
            if not self.base_diffusion.num_timesteps - 1 in indices:
                indices.append(self.base_diffusion.num_timesteps - 1)
            batch_size = self.configs.train.batch[1]
            num_iters_epoch = math.ceil(len(self.datasets[phase]) / batch_size)
            mean_psnr = mean_lpips = mean_mse = 0
            for ii, data in enumerate(self.dataloaders[phase]):
                data = self.prepare_data(data, phase='val')
                if 'gt' in data:
                    im_lq, im_gt = (data['lq'], data['gt'])
                else:
                    im_lq = data['lq']
                num_iters = 0
                if self.configs.model.params.cond_lq:
                    lq_interpol = F.interpolate(im_lq, scale_factor=16, mode='bicubic')
                    model_kwargs = {'lq': lq_interpol}
                else:
                    model_kwargs = None
                tt = torch.tensor(
                    [self.base_diffusion.num_timesteps] * im_lq.shape[0],
                    dtype=torch.int64,
                ).cuda(
                )
                for sample in self.base_diffusion.p_sample_loop_progressive(
                    y=im_lq,
                    model=self.ema_model if self.configs.train.use_ema_val else self.model,
                    first_stage_model=self.autoencoder,
                    noise=None,
                    clip_denoised=False,
                    model_kwargs=model_kwargs,
                    device=f'cuda:{self.rank}',
                    progress=False,
                ):
                    sample_decode = {}
                    if num_iters in indices:
                        for key, value in sample.items():
                            if key in ['sample']:
                                sample_decode[key] = self.base_diffusion.decode_first_stage(value, self.autoencoder)
                        im_sr_progress = sample_decode['sample']
                        if num_iters + 1 == 1:
                            im_sr_all = im_sr_progress
                        else:
                            im_sr_all = torch.cat((im_sr_all, im_sr_progress), dim=1)
                    num_iters += 1
                    tt -= 1
                if 'gt' in data:
                    mean_psnr += util_image.batch_PSNR(sample_decode['sample'], im_gt)
                    mean_lpips += self.lpips_loss(sample_decode['sample'], im_gt).sum().item()
                    mean_mse += mean_flat((sample_decode['sample'] - im_gt) ** 2).sum().item()
                if (ii + 1) % self.configs.train.log_freq[2] == 0:
                    self.logger.info(f'Validation: {ii + 1:02d}/{num_iters_epoch:02d}...')
                    im_sr_all = rearrange(im_sr_all, 'b (k c) h w -> (b k) c h w', c=im_lq.shape[1])
                    self.logging_image(
                        im_sr_all,
                        tag='progress',
                        phase=phase,
                        add_global_step=False,
                        nrow=len(indices),
                    )
                    if 'gt' in data:
                        self.logging_image(im_gt, tag='gt', phase=phase, add_global_step=False)
                    self.logging_image(im_lq, tag='lq', phase=phase, add_global_step=True)
            if 'gt' in data:
                mean_psnr /= len(self.datasets[phase])
                mean_lpips /= len(self.datasets[phase])
                mean_mse /= len(self.datasets[phase])
                self.logger.info(
                    f'Validation Metric: PSNR,{mean_psnr:5.2f}, MSE,{mean_mse:5.2f}, LPIPS,{mean_lpips:6.4f}...',
                )
            self.logger.info('=' * 100)
            if not (self.configs.train.use_ema_val and hasattr(self.configs.train, 'ema_rate')):
                self.model.train()

def replace_nan_in_batch(im_lq, im_gt):
    if torch.isnan(im_lq).sum() > 0:
        valid_index = []
        im_lq = im_lq.contiguous()
        for ii in range(im_lq.shape[0]):
            if torch.isnan(im_lq[ii,]).sum() == 0:
                valid_index.append(ii)
        assert len(valid_index) > 0
        im_lq, im_gt = (im_lq[valid_index,], im_gt[valid_index,])
        flag = True
    else:
        flag = False
    return (im_lq, im_gt, flag)

def my_worker_init_fn(worker_id):
    np.random.seed(np.random.get_state()[1][0] + worker_id)
