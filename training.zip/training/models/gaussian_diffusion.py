"""Exponential residual-shifting diffusion for three-component fluid fields."""
import enum
import math
import numpy as np
import torch as th
import torch.nn.functional as F
from .basic_ops import mean_flat

def get_named_eta_schedule(
    schedule_name,
    num_diffusion_timesteps,
    min_noise_level,
    etas_end=0.99,
    kappa=1.0,
    kwargs=None,
):
    if schedule_name != 'exponential':
        raise ValueError('Only the exponential fluid-flow schedule is supported.')
    power = kwargs.get('power', None)
    etas_start = min(min_noise_level / kappa, min_noise_level)
    increaser = math.exp(1 / (num_diffusion_timesteps - 1) * math.log(etas_end / etas_start))
    base = np.ones([num_diffusion_timesteps]) * increaser
    power_timestep = np.linspace(0, 1, num_diffusion_timesteps, endpoint=True) ** power
    power_timestep *= num_diffusion_timesteps - 1
    sqrt_etas = np.power(base, power_timestep) * etas_start
    return sqrt_etas

class ModelMeanType(enum.Enum):
    START_X = enum.auto()

class LossType(enum.Enum):
    MSE = enum.auto()

def _extract_into_tensor(arr, timesteps, broadcast_shape):
    res = th.from_numpy(arr).to(device=timesteps.device)[timesteps].float()
    while len(res.shape) < len(broadcast_shape):
        res = res[..., None]
    return res.expand(broadcast_shape)

class GaussianDiffusion:
    """Residual-shifting diffusion in normalized flow space; x-start prediction and unweighted MSE only."""

    def __init__(
        self,
        *,
        sqrt_etas,
        kappa,
        model_mean_type,
        loss_type,
        sf=16,
        scale_factor=None,
        normalize_input=True,
        latent_flag=True,
    ):
        self.kappa = kappa
        self.model_mean_type = model_mean_type
        self.loss_type = loss_type
        self.scale_factor = scale_factor
        self.normalize_input = normalize_input
        self.latent_flag = latent_flag
        self.sf = sf
        self.sqrt_etas = sqrt_etas
        self.etas = sqrt_etas ** 2
        assert len(self.etas.shape) == 1, 'etas must be 1-D'
        assert (self.etas > 0).all() and (self.etas <= 1).all()
        self.num_timesteps = int(self.etas.shape[0])
        self.etas_prev = np.append(0.0, self.etas[:-1])
        self.alpha = self.etas - self.etas_prev
        self.posterior_variance = kappa ** 2 * self.etas_prev / self.etas * self.alpha
        self.posterior_variance_clipped = np.append(self.posterior_variance[1], self.posterior_variance[1:])
        self.posterior_log_variance_clipped = np.log(self.posterior_variance_clipped)
        self.posterior_mean_coef1 = self.etas_prev / self.etas
        self.posterior_mean_coef2 = self.alpha / self.etas
        weight_loss_mse = 0.5 / self.posterior_variance_clipped * (self.alpha / self.etas) ** 2
        self.weight_loss_mse = weight_loss_mse

    def q_sample(self, x_start, y, t, noise=None):
        if noise is None:
            noise = th.randn_like(x_start)
        assert noise.shape == x_start.shape
        return _extract_into_tensor(self.etas, t, x_start.shape) * (y - x_start) + x_start + _extract_into_tensor(self.sqrt_etas * self.kappa, t, x_start.shape) * noise

    def q_posterior_mean_variance(self, x_start, x_t, t):
        assert x_start.shape == x_t.shape
        posterior_mean = _extract_into_tensor(self.posterior_mean_coef1, t, x_t.shape) * x_t + _extract_into_tensor(self.posterior_mean_coef2, t, x_t.shape) * x_start
        posterior_variance = _extract_into_tensor(self.posterior_variance, t, x_t.shape)
        posterior_log_variance_clipped = _extract_into_tensor(self.posterior_log_variance_clipped, t, x_t.shape)
        assert posterior_mean.shape[0] == posterior_variance.shape[0] == posterior_log_variance_clipped.shape[0] == x_start.shape[0]
        return (posterior_mean, posterior_variance, posterior_log_variance_clipped)

    def p_mean_variance(
        self,
        model,
        x_t,
        y,
        t,
        clip_denoised=True,
        denoised_fn=None,
        model_kwargs=None,
    ):
        if model_kwargs is None:
            model_kwargs = {}
        B, C = x_t.shape[:2]
        assert t.shape == (B,)
        model_output = model(self._scale_input(x_t, t), t, **model_kwargs)
        model_variance = _extract_into_tensor(self.posterior_variance, t, x_t.shape)
        model_log_variance = _extract_into_tensor(self.posterior_log_variance_clipped, t, x_t.shape)

        def process_xstart(x):
            if denoised_fn is not None:
                x = denoised_fn(x)
            if clip_denoised:
                return x.clamp(-1, 1)
            return x
        pred_xstart = process_xstart(model_output)
        model_mean, _, _ = self.q_posterior_mean_variance(x_start=pred_xstart, x_t=x_t, t=t)
        assert model_mean.shape == model_log_variance.shape == pred_xstart.shape == x_t.shape
        return {
            'mean': model_mean,
            'variance': model_variance,
            'log_variance': model_log_variance,
            'pred_xstart': pred_xstart,
        }

    def p_sample(
        self,
        model,
        x,
        y,
        t,
        clip_denoised=True,
        denoised_fn=None,
        model_kwargs=None,
        noise_repeat=False,
    ):
        out = self.p_mean_variance(
            model,
            x,
            y,
            t,
            clip_denoised=clip_denoised,
            denoised_fn=denoised_fn,
            model_kwargs=model_kwargs,
        )
        noise = th.randn_like(x)
        if noise_repeat:
            noise = noise[0,].repeat(x.shape[0], 1, 1, 1)
        nonzero_mask = (t != 0).float().view(-1, *[1] * (len(x.shape) - 1))
        sample = out['mean'] + nonzero_mask * th.exp(0.5 * out['log_variance']) * noise
        return {'sample': sample, 'pred_xstart': out['pred_xstart'], 'mean': out['mean']}

    def p_sample_loop(
        self,
        y,
        model,
        first_stage_model=None,
        consistencydecoder=None,
        noise=None,
        noise_repeat=False,
        clip_denoised=True,
        denoised_fn=None,
        model_kwargs=None,
        device=None,
        progress=False,
    ):
        final = None
        for sample in self.p_sample_loop_progressive(
            y,
            model,
            first_stage_model=first_stage_model,
            noise=noise,
            noise_repeat=noise_repeat,
            clip_denoised=clip_denoised,
            denoised_fn=denoised_fn,
            model_kwargs=model_kwargs,
            device=device,
            progress=progress,
        ):
            final = sample['sample']
        with th.no_grad():
            out = self.decode_first_stage(
                final,
                first_stage_model=first_stage_model,
                consistencydecoder=consistencydecoder,
            )
        return out

    def p_sample_loop_progressive(
        self,
        y,
        model,
        first_stage_model=None,
        noise=None,
        noise_repeat=False,
        clip_denoised=True,
        denoised_fn=None,
        model_kwargs=None,
        device=None,
        progress=False,
    ):
        """Yield every reverse step in the original order, including the noise draw at the final step."""
        if device is None:
            device = next(model.parameters()).device
        z_y = self.encode_first_stage(y, first_stage_model, up_sample=True)
        if noise is None:
            noise = th.randn_like(z_y)
        if noise_repeat:
            noise = noise[0,].repeat(z_y.shape[0], 1, 1, 1)
        z_sample = self.prior_sample(z_y, noise)
        indices = list(range(self.num_timesteps))[::-1]
        if progress:
            from tqdm.auto import tqdm
            indices = tqdm(indices)
        for i in indices:
            t = th.tensor([i] * y.shape[0], device=device)
            with th.no_grad():
                out = self.p_sample(
                    model,
                    z_sample,
                    z_y,
                    t,
                    clip_denoised=clip_denoised,
                    denoised_fn=denoised_fn,
                    model_kwargs=model_kwargs,
                    noise_repeat=noise_repeat,
                )
                yield out
                z_sample = out['sample']

    def decode_first_stage(self, z_sample, first_stage_model=None, consistencydecoder=None):
        """The flow is modeled directly; no latent decoder or image autoencoder is used."""
        return z_sample

    def encode_first_stage(self, y, first_stage_model, up_sample=False):
        """Keep the original bicubic upsampling before adding diffusion noise."""
        if up_sample and self.sf != 1:
            y = F.interpolate(y, scale_factor=self.sf, mode='bicubic')
        return y

    def prior_sample(self, y, noise=None):
        if noise is None:
            noise = th.randn_like(y)
        t = th.tensor([self.num_timesteps - 1] * y.shape[0], device=y.device).long()
        return y + _extract_into_tensor(self.kappa * self.sqrt_etas, t, y.shape) * noise

    def training_losses(
        self,
        model,
        x_start,
        y,
        t,
        first_stage_model=None,
        model_kwargs=None,
        noise=None,
    ):
        """Return the original per-sample MSE, noisy field, and predicted clean field. LPIPS is added by the trainer."""
        if model_kwargs is None:
            model_kwargs = {}
        z_y = self.encode_first_stage(y, first_stage_model, up_sample=True)
        z_start = self.encode_first_stage(x_start, first_stage_model, up_sample=False)
        if noise is None:
            noise = th.randn_like(z_start)
        z_t = self.q_sample(z_start, z_y, t, noise=noise)
        terms = {}
        model_output = model(self._scale_input(z_t, t), t, **model_kwargs)
        target = z_start
        assert model_output.shape == target.shape == z_start.shape
        terms['mse'] = mean_flat((target - model_output) ** 2)
        weights = 1
        terms['mse'] *= weights
        pred_zstart = model_output
        return (terms, z_t, pred_zstart)

    def _scale_input(self, inputs, t):
        """Fields are already normalized by the loader; do not rescale them again."""
        return inputs
