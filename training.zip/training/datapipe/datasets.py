"""Training/validation data. Keep directory and extension order consistent with the original experiment."""
import os
import numpy as np
import torch
from torch.utils import data

class RealFluidFlowDataset(data.Dataset):
    """Load paired 16x16 and 256x256 three-column text fields; pairing follows sorted lists, not token replacement."""

    def __init__(self, opt):
        super(RealFluidFlowDataset, self).__init__()
        self.lqp = []
        self.gtp = []
        dir_paths = opt['dir_paths_train']
        for dir_path in dir_paths:
            for ext in opt['im_exts']:
                sorted_lq = sorted(
                    [os.path.join(dir_path, f) for f in os.listdir(dir_path) if f.endswith(ext) and any((x in f for x in ['a16in', 'b16in']))],
                )
                sorted_gt = sorted(
                    [os.path.join(dir_path, f) for f in os.listdir(dir_path) if f.endswith(ext) and any((x in f for x in ['aout', 'bout']))],
                )
                self.lqp.extend(sorted_lq[::1])
                self.gtp.extend(sorted_gt[::1])
        assert len(self.lqp) == len(self.gtp)

    def __getitem__(self, index):
        """Normalize each component with its LQ maximum magnitude in NumPy float64, then convert to torch.float32."""
        lq_path = self.lqp[index]
        gt_path = self.gtp[index]
        try:
            with open(lq_path, 'r') as f:
                lines = f.readlines()
                input_data = np.array([list(map(float, line.split())) for line in lines])
                lq1_max = np.max(np.abs(input_data[:, 0]))
                lq2_max = np.max(np.abs(input_data[:, 1]))
                lq3_max = np.max(np.abs(input_data[:, 2]))
                lq1 = input_data[:, 0].reshape(16, 16) / lq1_max
                lq2 = input_data[:, 1].reshape(16, 16) / lq2_max
                lq3 = input_data[:, 2].reshape(16, 16) / lq3_max
        except:
            raise ValueError(f"Error loading input file '{lq_path}'")
        try:
            with open(gt_path, 'r') as f:
                lines = f.readlines()
                output_data = np.array([list(map(float, line.split())) for line in lines])
                gt1 = output_data[:, 0].reshape(256, 256) / lq1_max
                gt2 = output_data[:, 1].reshape(256, 256) / lq2_max
                gt3 = output_data[:, 2].reshape(256, 256) / lq3_max
        except:
            raise ValueError(f"Error loading output file '{gt_path}'")
        im_lq = torch.tensor(np.stack([lq1, lq2, lq3]), dtype=torch.float)
        im_gt = torch.tensor(np.stack([gt1, gt2, gt3]), dtype=torch.float)
        return_d = {'lq': im_lq, 'gt': im_gt}
        return return_d

    def __len__(self):
        return len(self.lqp)

class RealFluidFlowDatasetVal(data.Dataset):
    """Load paired 16x16 and 256x256 three-column text fields; pairing follows sorted lists, not token replacement."""

    def __init__(self, opt):
        super().__init__()
        self.lqp = []
        self.gtp = []
        for dir_path in opt['dir_path']:
            for ext in opt['im_exts']:
                sorted_lq = sorted(
                    [os.path.join(dir_path, f) for f in os.listdir(dir_path) if f.endswith(ext) and any((x in f for x in ['a16in', 'b16in']))],
                )
                sorted_gt = sorted(
                    [os.path.join(dir_path, f) for f in os.listdir(dir_path) if f.endswith(ext) and any((x in f for x in ['aout', 'bout']))],
                )
                self.lqp.extend(sorted_lq[::1])
                self.gtp.extend(sorted_gt[::1])
        assert len(self.lqp) == len(self.gtp)
        self.lqp_all = self.lqp
        self.gtp_all = self.gtp

    def __len__(self):
        return len(self.lqp_all)

    def __getitem__(self, index):
        """Normalize each component with its LQ maximum magnitude in NumPy float64, then convert to torch.float32."""
        lq_path = self.lqp_all[index]
        gt_path = self.gtp_all[index]
        try:
            with open(lq_path, 'r') as f:
                lines = f.readlines()
                input_data = np.array([list(map(float, line.split())) for line in lines])
                lq1_max = np.max(np.abs(input_data[:, 0]))
                lq2_max = np.max(np.abs(input_data[:, 1]))
                lq3_max = np.max(np.abs(input_data[:, 2]))
                lq1 = input_data[:, 0].reshape(16, 16) / lq1_max
                lq2 = input_data[:, 1].reshape(16, 16) / lq2_max
                lq3 = input_data[:, 2].reshape(16, 16) / lq3_max
        except:
            raise ValueError(f"Error loading input file '{lq_path}'")
        try:
            with open(gt_path, 'r') as f:
                lines = f.readlines()
                output_data = np.array([list(map(float, line.split())) for line in lines])
                gt1 = output_data[:, 0].reshape(256, 256) / lq1_max
                gt2 = output_data[:, 1].reshape(256, 256) / lq2_max
                gt3 = output_data[:, 2].reshape(256, 256) / lq3_max
        except:
            raise ValueError(f"Error loading output file '{gt_path}'")
        im_lq = torch.tensor(np.stack([lq1, lq2, lq3]), dtype=torch.float)
        im_gt = torch.tensor(np.stack([gt1, gt2, gt3]), dtype=torch.float)
        out = {'image': im_lq, 'lq': im_lq}
        out['gt'] = im_gt
        return out

def create_dataset(config):
    """Only the training and validation flow loaders are part of this release."""
    if config['type'] == 'fluidflow':
        return RealFluidFlowDataset(config['params'])
    if config['type'] == 'fluidflowval':
        return RealFluidFlowDatasetVal(config['params'])
    raise ValueError('Expected fluidflow or fluidflowval dataset.')
