#!/usr/bin/env bash
#SBATCH --job-name=flow_train_15
#SBATCH --gres=gpu:4
#SBATCH --mem=100G
#SBATCH --cpus-per-task=16
#SBATCH --output=train_%j.out
#SBATCH --error=train_%j.err
set -euo pipefail

# Activate your existing PyTorch/CUDA environment BEFORE running this script.
# Local: bash run.sh. Slurm: cd to this folder, then sbatch run.sh.
# Add your cluster's partition/account directives above if required.
cd "${SLURM_SUBMIT_DIR:-$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)}"

# The original launcher used four GPUs. Keep the global batch in the YAML at 64.
NUM_GPUS="${NUM_GPUS:-4}"
CONFIG_PATH="${CONFIG_PATH:-configs/fluidflow.yaml}"
SAVE_DIR="${SAVE_DIR:-logging}"
# Empty means a NEW 15-step experiment. Resume only a matching 15-step run.
RESUME_CHECKPOINT="${RESUME_CHECKPOINT:-}"
if [[ -z "${SLURM_JOB_ID:-}" ]]; then
    export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1,2,3}"
fi

args=(--cfg_path "$CONFIG_PATH" --save_dir "$SAVE_DIR")
if [[ -n "$RESUME_CHECKPOINT" ]]; then
    [[ -f "$RESUME_CHECKPOINT" ]] || { echo "Missing resume checkpoint: $RESUME_CHECKPOINT" >&2; exit 1; }
    args+=(--resume "$RESUME_CHECKPOINT")
fi
torchrun --standalone --nproc_per_node="$NUM_GPUS" --nnodes=1 main.py "${args[@]}"
